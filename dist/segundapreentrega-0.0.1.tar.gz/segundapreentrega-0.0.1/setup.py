from setuptools import setup

setup(
    author='Miguel Moyano',
    author_email='migmoyano86@gmail.com',
    description='Segunda Preentrega',
    version='0.0.1',
    name='segundapreentrega',
    packages=['segunda_preentrega_Moyano', 'segunda_preentrega_Moyano.primera_preentrega', 'segunda_preentrega_Moyano.segunda_preentrega']
)